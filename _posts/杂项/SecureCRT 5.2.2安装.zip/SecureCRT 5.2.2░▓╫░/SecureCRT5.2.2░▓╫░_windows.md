---
layout: default
author: muyalei
title: SecureCRT5.2.2安装_windows
date: 2021-09-29
tags:
	- 工具使用
---

**参考：**

[https://blog.csdn.net/weixin_30339969/article/details/96730580](https://blog.csdn.net/weixin_30339969/article/details/96730580)

- 注册码（亲测可用）
```
Name: Apollo Interactive
Company: Apollo Interactive
Serial Number: 03-50-023223
License Key: ABMVSR NA46JN V3D2GG TJDKFQ ACS3S4 B18P54 ZPCQWM 9756P2
Issue Date: 01-20-2006
```

- 下载地址
```
https://www.vandyke.com/download/securecrt/5.2/index.html
用户名：70907583@qq.com
密码：3c7ae7
```
或：[]()

- 遇到问题

 1. 中文横向

 Options > SessionOptions > Apperance > Font > 选择不带@符号的字体 > apply

 2. 显示中文乱码，且全局设置不生效

 [https://blog.csdn.net/ningxiaopeng08/article/details/50437352](https://blog.csdn.net/ningxiaopeng08/article/details/50437352)

#!/usr/bin/env python
from resource_management import *
from resource_management.libraries.script.script import Script
import sys, os, glob
from resource_management.libraries.functions.version import format_stack_version
from resource_management.libraries.functions.default import default


# server configurations
config = Script.get_config()


# params from flink-conf.yaml
flink_user = config['configurations']['flink-env']['flink.user']
flink_group = config['configurations']['flink-env']['flink.group']
flink_base_dir = config['configurations']['flink-env']['flink.base.dir']
flink_base_dir_slave = config['configurations']['flink-env']['flink.base.dir.slave']
hadoop_conf_dir = config['configurations']['flink-env']['hadoop.conf.dir']
pid_file_dir = config['configurations']['flink-env']['pid.file.dir']
pid_file = pid_file_dir+'/flink.pid'
log_file_dir = config['configurations']['flink-env']['log.file.dir']
flink_edition_name = config['configurations']['flink-env']['flink.edition.name']

flink_conf_yaml_content = config['configurations']['flink-conf-yaml']['flink_conf_yaml_content']

flink_start_command = config['configurations']['flink-env']['flink.start.command']

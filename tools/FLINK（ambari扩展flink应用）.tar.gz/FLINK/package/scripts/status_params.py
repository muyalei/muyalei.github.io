# -*- coding: utf-8 -*-
#!/usr/bin/env python



from resource_management import *

config = Script.get_config()

pid_file_dir = config['configurations']['flink-env']['pid.file.dir']
pid_file = format("{pid_file_dir}/flink-{flink_user}-taskexecutor.pid")
#pid_file_slave = format("{pid_file_dir}/flink-slave.pid")

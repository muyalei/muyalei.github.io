#!/usr/bin/python
# -*- coding:utf-8 -*-#


from resource_management import *
import time,sys,os,glob,pwd,grp,signal
reload(sys)
sys.setdefaultencoding('utf-8') 


class FlinkMaster(Script):
    
    #安装flink
    def install(self,env):

        import params
        env.set_params(params)
      
        #安装依赖文件（<osSpecific>标签下<packages>标签中列出的依赖，ambari会尝试通过yum或apt-get安装）        
        self.install_packages(env)
       
        #检查用户组flink是否存在
        try:
            grp.getgrnam(params.flink_group)
        except KeyError:
            for gid in range(10000,50000,5): #500以内是系统程序用户组使用的gid
                try:
                    grp.getgrgid(gid) #判断当前gid是否存在，不存在时进入错误处理流程 
                except KeyError:
                    cmd = 'groupadd -g {} {}'.format(gid,params.flink_group) #新建用户组
                    os.system(cmd)
                    break #成功新建用户组，则跳出循环
                       
        #检查用户flink是否存在，不存在就创建
        try:
            pwd.getpwnam(params.flink_user)
        except KeyError:
            for uid in range(10000,50000,5):
                try:
                    pwd.getpwuid(uid)
                except KeyError:
                    cmd = 'useradd -u {} -g {} -m {}'.format(uid,params.flink_group,params.flink_user) #新建用户
                    os.system(cmd)
                    cmd = 'echo "{}" |passwd --stdin {}'.format(params.flink_user,params.flink_user)
                    os.system(cmd)
                    break



        """ 
        #检查用户组，不存在就创建
        try:
            grp.getgrnam(params.flink_group)
        except KeyError:
            Group(group_name=params.flink_group)

        #检查用户，不存在就创建
        try:
            pwd.getpwnam(params.flink_user)
        except KeyError:
            User(username=params.flink_user,
                 gid=params.flink_group,
                 groups=[params.flink_group],
                 ignore_failures=True
                 )
        #创建目录
        Directory([params.log_file_dir, params.pid_file_dir],
                  mode=0755,
                  cd_access='a',
                  owner=params.flink_user,
                  group=params.flink_group,
                  create_parents=True
                  )
        """
        #创建存放pid文件的目录
        Directory(params.pid_file_dir,mode=0755,cd_access='a',owner=params.flink_user,group=params.flink_group,create_parents=True)
        
        #安装flink 
        cmd = format("cd {flink_base_dir};rm -rf flink;tar -zxvf {flink_edition_name};mv flink-1.9.1 flink")
        Execute(cmd,user=params.flink_user)
      
        #将修改后的flink-conf.yaml文件内容写入flink安装目录下的conf/flink-conf.yaml文件中
        #flink_conf_yaml_content=InlineTemplate(params.flink_conf_yaml_content)
        #File(format("{flink_base_dir}/flink/conf/flink-conf.yaml"), content=flink_conf_yaml_content, owner=params.flink_user)
 
        #确认params.flink_user对所有文件有权限
        cmd = format("chown -R {flink_user}:{flink_group} {flink_base_dir}")
        Execute(cmd)

        #删除安装包
        #cmd = format("cd {flink_base_dir_master}; rm -rf {flink_edition_name}")
        #Execute(cmd,user=params.flink_user)
        
        Execute('echo "flink install complete"')

   
    #配置flink
    def configure(self,env):

        import params,status_params
        env.set_params(params)
        env.set_params(status_params)
       
        #声明hadoop位置
        cmd = format("export HADOOP_CONF_DIR={hadoop_conf_dir}")
        Execute(cmd,user=params.flink_user)        
       
        #确保pid存放目录存在
        Directory(params.pid_file_dir,mode=0755,cd_access='a',owner=params.flink_user,group=params.flink_group,create_parents=True)

        #将用户填写的flink的pid文件存放路径追加到flink安装目录下bin目录的config.sh文件中
        cmd = format('echo "FLINK_PID_DIR=\'{pid_file_dir}\'" >> {flink_base_dir}/flink/bin/config.sh')
        Execute(cmd,user=params.flink_user)        

        #将修改后的flink-conf.yaml文件内容写入flink安装目录下的conf/flink-conf.yaml文件中
        flink_conf_yaml_content=InlineTemplate(params.flink_conf_yaml_content) 
        File(format("{flink_base_dir}/flink/conf/flink-conf.yaml"), content=flink_conf_yaml_content, owner=params.flink_user)

        #覆写flink-conf.yaml
        #properties_content=InlineTemplate(params.flink_yaml_content)
        #File(format("{flink_base_dir}/flink/conf/flink-conf.yaml"), content=properties_content, owner=params.flink_user)

        Execute('echo "Configuration complete"')

    

    def stop(self,env):
        
        import params
        env.set_params(params)
        
        #正常情况下，通过安装包中的脚本停止服务
        cmd = format('cd {flink_base_dir}/flink/bin/;./stop-cluster.sh')
        Execute(cmd,user=params.flink_user)        

        #读取flink的相关进程pid
        with open(params.pid_file_dir+'/flink.pid','r') as f:
            pid_list = f.read().split('\n')
            f.close()
        #正常杀死进程
        """
        for pid in pid_list:
            Execute('kill {pid}'.format(pid=pid))
        """
        os.system('kill {pids}'.format(pids=' '.join(pid_list)))
        #再强杀一次，确保进程全部杀死
        """
        for pid in pid_list:
            Execute('kill -9 {pid}'.format(pid=pid))
        """
        os.system('kill -9 {pids}'.format(pids=' '.join(pid_list)))

        Execute('echo "Stop flink success"')        


    def start(self,env):

        import params
        env.set_params(params)
      
        #配置文件生效
        self.configure(env)
       
        #启动flink
        cmd = format("cd {flink_base_dir}/flink/bin; ./{flink_start_command}")
        Execute(cmd,user=params.flink_user)  
       
        #将相关pid写入/var/run/flink/flink.pid
        """
        pid_file_list = os.listdir(params.pid_file_dir) #执行start_cluster.sh对应的pid文件
        if 'flink.pid' in pid_file_list:
            pid_file_list.remove('flink.pid')
         
        cmd = format('cat {pid_file_dir}/{file1} {pid_file_dir}/{file2} > {pid_file}'.format(file1=pid_file_list[0],file2=pid_file_list[1]))        
        Execute(cmd,user=params.flink_user)
        """
        cmd = format('cat {pid_file_dir}/flink-{flink_user}-standalonesession.pid {pid_file_dir}/flink-{flink_user}-taskexecutor.pid > {pid_file_dir}/flink.pid',user=params.flink_user)
        Execute(cmd,user=params.flink_user)
         
        Execute('echo "Start flink success"',user=params.flink_user)
        
   
    def status(self,env):
        import status_params
        env.set_params(status_params) 
       
        #使用内置方法检查pid文件状态 
        check_process_status(status_params.pid_file)




if __name__=='__main__':
    FlinkMaster().execute()  

